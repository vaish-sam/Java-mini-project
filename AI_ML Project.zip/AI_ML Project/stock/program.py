import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import numpy as np

# Step 1: Load the dataset
data = pd.read_csv('data.csv', parse_dates=['Date'], index_col='Date')

# Step 2: Plot the original data
plt.figure(figsize=(10,6))
plt.plot(data['Close'], label='Close Price')
plt.title('Stock Prices Over Time')
plt.xlabel('Date')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

# Step 3: Prepare data for ARIMA model
# Let's use the 'Close' price for prediction
series = data['Close']

# Step 4: Split data into train and test sets
train_size = int(len(series) * 0.8)
train, test = series[:train_size], series[train_size:]

# Step 5: Fit the ARIMA model
model = ARIMA(train, order=(5,1,0))  # (p,d,q) parameters
model_fit = model.fit()

# Step 6: Make predictions
predictions = model_fit.forecast(steps=len(test))

# Step 7: Plot predictions vs actual results
plt.figure(figsize=(10,6))
plt.plot(test.index, test, label='Actual Prices')
plt.plot(test.index, predictions, color='red', label='Predicted Prices')
plt.title('Stock Price Prediction')
plt.xlabel('Date')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

# Step 8: Calculate performance metrics
mse = mean_squared_error(test, predictions)
rmse = np.sqrt(mse)
print(f'Root Mean Squared Error: {rmse}')

# Step 9: Forecast future values
future_steps = 30  # Predict the next 30 days
forecast = model_fit.forecast(steps=future_steps)

# Plot the forecast
plt.figure(figsize=(10,6))
plt.plot(series.index[-100:], series[-100:], label='Historical Data')
plt.plot(pd.date_range(start=series.index[-1], periods=future_steps, freq='B'), forecast, color='green', label='Forecast')
plt.title('Stock Price Forecast')
plt.xlabel('Date')
plt.ylabel('Stock Price')
plt.legend()
plt.show()
